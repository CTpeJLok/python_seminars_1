from setuptools import setup

setup(name='pi2143oop',
      version='1.6',
      description='OOP tasks',
      packages=['pi2143oop'],
      author_email='good-i-evil@yandex.ru',
      zip_safe=False)
