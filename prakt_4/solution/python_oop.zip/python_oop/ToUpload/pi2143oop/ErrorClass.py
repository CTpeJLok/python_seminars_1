class Error(Exception):
    pass
