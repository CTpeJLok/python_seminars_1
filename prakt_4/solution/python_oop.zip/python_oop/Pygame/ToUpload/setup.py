from setuptools import setup

setup(name='pi2143ooppg',
      version='0.2',
      description='OOP tasks with pygame',
      packages=['pi2143ooppg'],
      author_email='good-i-evil@yandex.ru',
      zip_safe=False)
