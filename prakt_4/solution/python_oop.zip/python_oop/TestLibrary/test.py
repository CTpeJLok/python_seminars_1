# import pi2143oop as p
#
# p.

from pi2143oop import *

c = Canvas()

d = Triangle(c, 0, 0, 5, 4, 10, 0)
d.draw_c('+')

c.print()
